# Deployment Guide for COBOL Quest

## Prerequisites
- Node.js 18+
- SQLite (or another database if configured)
- PM2 (optional, for process management)

## Environment Variables
Create a `.env` file on the server with the following:

```env
DATABASE_URL="file:./prod.db"
# NEXT_PUBLIC_... variables if needed
```

## Deployment Steps

1.  **Upload Files**: Upload the project files to the server (excluding `node_modules`, `.next`, and `.git`).
2.  **Install Dependencies**:
    ```bash
    npm install --production
    ```
    *Note: `sharp` is included for image optimization.*

3.  **Database Setup**:
    Initialize the database schema:
    ```bash
    npx prisma db push
    ```
    *(Note: Use `npx prisma migrate deploy` only if you have generated migration files locally)*

4.  **Build the Application**:
    ```bash
    npm run build
    ```

5.  **Start the Application**:
    Using `npm start`:
    ```bash
    npm start
    ```
    
    Using PM2 (Recommended):
    ```bash
    pm2 start npm --name "cobol-quest" -- start
    ```

## Maintenance
- **Update Application**: Pull new code, run `npm install`, `npx prisma db push`, `npm run build`, and restart the process.
- **Backup Database**: Regularly backup `prod.db` (or your configured database).
